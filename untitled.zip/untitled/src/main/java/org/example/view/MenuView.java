package org.example.view;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MenuView {

    private final Scene scene;

    public MenuView(Stage stage) {
        Button startBtn = new Button("Iniciar Juego");
        Button exitBtn  = new Button("Salir");

        startBtn.setOnAction(e -> {
            GameView gameView = new GameView(stage, 1);
            stage.setScene(gameView.getScene());
        });

        exitBtn.setOnAction(e -> stage.close());

        VBox root = new VBox(20, startBtn, exitBtn);
        root.setAlignment(javafx.geometry.Pos.CENTER);
        this.scene = new Scene(root, 800, 600);
    }

    public Scene getScene() { return scene; }
}