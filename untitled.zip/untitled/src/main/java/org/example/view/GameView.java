package org.example.view;

import javafx.animation.AnimationTimer;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import org.example.model.game.Game;
import org.example.model.level.*;
import org.example.model.tower.*;

public class GameView {

    private final Scene scene;
    private Game game;
    private int currentLevel;
    private final Stage stage;

    public GameView(Stage stage, int levelNumber) {
        this.stage = stage;
        this.currentLevel = levelNumber;

        // Cargar modelo
        LevelLoader loader = new LevelLoader();
        TowerFactory towerFactory = new TowerFactory();
        LevelData data = loader.load("/nivel" + levelNumber + ".xml");
        this.game = new Game(data.getRoute(), data.getLevel(), data.getInitialMoney());
        for (InitialTower it : data.getInitialTowers()) {
            game.addTower(towerFactory.create(it.getType()), it.getSlot());
        }

        // Canvas donde se dibuja todo
        Canvas canvas = new Canvas(800, 520);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // HUD arriba
        Label moneyLabel = new Label("$" + game.getPlayer().getMoney());
        Label scoreLabel = new Label("Score: " + game.getPlayer().getScore());
        HBox hud = new HBox(20, moneyLabel, scoreLabel);

        BorderPane root = new BorderPane();
        root.setTop(hud);
        root.setCenter(canvas);
        this.scene = new Scene(root, 800, 600);

        GameRenderer renderer = new GameRenderer(gc);

        // El loop del juego: se llama ~60 veces por segundo
        long[] lastTime = {System.nanoTime()};

        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                double deltaTime = (now - lastTime[0]) / 1_000_000_000.0;
                lastTime[0] = now;

                game.update(deltaTime);

                // Actualizar HUD
                moneyLabel.setText("$" + game.getPlayer().getMoney());
                scoreLabel.setText("Score: " + game.getPlayer().getScore());

                // Dibujar
                renderer.render(game,deltaTime);

                // Verificar fin de nivel
                if (game.isGameOver()) {
                    stop();
                    showDefeat();
                } else if (game.isWin()) {
                    stop();
                    showVictory();
                }
            }
        };
        timer.start();
    }

    private void showVictory() {
        if (currentLevel >= 3) {
            // Mostrar cartel final
            System.out.println("GANASTE TODO");
            // podés hacer una escena de victoria acá
        } else {
            // Pasar al siguiente nivel
            GameView next = new GameView(stage, currentLevel + 1);
            stage.setScene(next.getScene());
        }
    }

    private void showDefeat() {
        MenuView menu = new MenuView(stage);
        stage.setScene(menu.getScene());
    }

    public Scene getScene() { return scene; }
}