package org.example.view;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import org.example.model.enemy.Enemy;
import org.example.model.game.Game;
import org.example.model.projectile.Projectile;
import org.example.model.tower.Tower;

public class GameRenderer {

    private final GraphicsContext gc;

    // sprites enemigos
    private final Image weakSprite;
    private final Image fastSprite;
    private final Image tankSprite;

    // tiles mapa
    private final Image grass;
    private final Image path;
    private final Image slot;
    private final Image bush1;
    private final Image bush2;

    private static final int TOWER_SIZE = 30;
    private static final int FRAME_COLS = 3;
    private static final int FRAME_ROWS = 4;
    private static final int TILE_SIZE = 64;

    public GameRenderer(GraphicsContext gc) {
        this.gc = gc;

        // enemigos
        weakSprite = new Image(getClass().getResourceAsStream("/sprites/zombie_weak_sheet.png"));
        fastSprite = new Image(getClass().getResourceAsStream("/sprites/zombie_fast_sheet.png"));
        tankSprite = new Image(getClass().getResourceAsStream("/sprites/zombie_tank_sheet.png"));

        // tiles
        grass = new Image(getClass().getResourceAsStream("/tiles/grass.png"));
        path  = new Image(getClass().getResourceAsStream("/tiles/greypath.png"));
        slot  = new Image(getClass().getResourceAsStream("/tiles/towerSlot.png"));

        bush1 = new Image(getClass().getResourceAsStream("/tiles/bush1.png"));
        bush2 = new Image(getClass().getResourceAsStream("/tiles/bush2.png"));
    }

    // ========================= ENEMIGOS =========================

    private void drawEnemy(Enemy enemy) {
        Image sheet = switch (enemy.getType()) {
            case "weak"   -> weakSprite;
            case "medium" -> fastSprite;
            case "strong" -> tankSprite;
            default       -> weakSprite;
        };

        double frameW = sheet.getWidth() / FRAME_COLS;
        double frameH = sheet.getHeight() / FRAME_ROWS;

        double dx = enemy.getDx();
        double dy = enemy.getDy();

        int row;
        if (Math.abs(dx) > Math.abs(dy)) {
            row = dx > 0 ? 1 : 3;
        } else {
            row = dy > 0 ? 0 : 2;
        }

        double animSpeed = enemy.getType().equals("strong") ? 8.0 : 2.0;
        int col = (int)(enemy.getAnimTime() * animSpeed) % FRAME_COLS;

        double srcX = col * frameW;
        double srcY = row * frameH;

        double destX = enemy.getX() - frameW / 2;
        double destY = enemy.getY() - frameH / 2;

        gc.drawImage(sheet, srcX, srcY, frameW, frameH, destX, destY, frameW, frameH);
    }

    // ========================= MAPA =========================

    private void drawGrass() {
        for (int x = 0; x < 800; x += TILE_SIZE) {
            for (int y = 0; y < 520; y += TILE_SIZE) {
                gc.drawImage(grass, x, y, TILE_SIZE, TILE_SIZE);
            }
        }
    }

    private void drawPath(Game game) {
        var route = game.getRoute();

        for (int i = 0; i < route.size() - 1; i++) {
            var p1 = route.getPoint(i);
            var p2 = route.getPoint(i + 1);

            if (p1.getX() == p2.getX()) {
                // vertical
                double yStart = Math.min(p1.getY(), p2.getY());
                double yEnd   = Math.max(p1.getY(), p2.getY());

                for (double y = yStart; y <= yEnd; y += TILE_SIZE) {
                    gc.drawImage(path,
                            p1.getX() - TILE_SIZE / 2,
                            y - TILE_SIZE / 2,
                            TILE_SIZE, TILE_SIZE);
                }

            } else {
                // horizontal
                double xStart = Math.min(p1.getX(), p2.getX());
                double xEnd   = Math.max(p1.getX(), p2.getX());

                for (double x = xStart; x <= xEnd; x += TILE_SIZE) {
                    gc.drawImage(path,
                            x - TILE_SIZE / 2,
                            p1.getY() - TILE_SIZE / 2,
                            TILE_SIZE, TILE_SIZE);
                }
            }
        }
    }

    private void drawSlots(Game game) {
        for (var p : game.getRoute().getTowerSpots()) {
            gc.drawImage(slot,
                    p.getX() - TILE_SIZE / 2,
                    p.getY() - TILE_SIZE / 2,
                    TILE_SIZE, TILE_SIZE);
        }
    }

    private void drawDecor() {
        gc.drawImage(bush1, 30, 64, TILE_SIZE, TILE_SIZE);
        gc.drawImage(bush2, 450, 120, TILE_SIZE, TILE_SIZE);
        gc.drawImage(bush2, 300, 30, TILE_SIZE, TILE_SIZE);
        gc.drawImage(bush1, 256, 192, TILE_SIZE, TILE_SIZE);
        gc.drawImage(bush1, 150, 400, TILE_SIZE, TILE_SIZE);
        gc.drawImage(bush1, 700, 256, TILE_SIZE, TILE_SIZE);
    }

    // ========================= RENDER =========================

    public void render(Game game, double deltaTime) {

        // fondo base
        drawGrass();

        // camino + slots + decoracion
        drawPath(game);
        drawSlots(game);
        drawDecor();

        // base
        gc.setFill(Color.BLUE);
        gc.fillRect(game.getBase().getX() - 20, game.getBase().getY() - 20, 40, 40);

        // torres
        gc.setFill(Color.GRAY);
        for (Tower t : game.getTowers()) {
            gc.fillRect(t.getX() - TOWER_SIZE / 2, t.getY() - TOWER_SIZE / 2, TOWER_SIZE, TOWER_SIZE);
        }

        // enemigos
        for (Enemy e : game.getEnemies()) {
            drawEnemy(e);
        }

        // proyectiles
        gc.setFill(Color.WHITE);
        for (Projectile p : game.getProjectiles()) {
            gc.fillOval(p.getX() - 4, p.getY() - 4, 8, 8);
        }
    }
}